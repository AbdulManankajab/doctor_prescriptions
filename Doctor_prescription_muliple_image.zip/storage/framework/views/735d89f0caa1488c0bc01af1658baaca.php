

<?php $__env->startSection('title', 'Print Prescription'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    @media print {
        @page {
            size: A4;
            margin: 15mm;
        }
        
        body {
            background: white !important;
        }
        
        .print-area {
            width: 100%;
            max-width: 100%;
            box-shadow: none !important;
        }
    }
    
    .prescription-header {
        border-bottom: 3px solid #667eea;
        margin-bottom: 20px;
        padding-bottom: 15px;
    }
    
    .clinic-name {
        font-size: 2rem;
        font-weight: bold;
        color: #667eea;
    }
    
    .prescription-table {
        border: 2px solid #dee2e6;
    }
    
    .prescription-table th {
        background-color: #f8f9fa;
        font-weight: 600;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row no-print mb-4">
    <div class="col-12 d-flex justify-content-between">
        <button onclick="window.print()" class="btn btn-primary px-4 rounded-pill">
            <i class="bi bi-printer me-2"></i> Print Prescription
        </button>
        <a href="<?php echo e(route('doctor.dashboard')); ?>" class="btn btn-outline-secondary px-4 rounded-pill">
            <i class="bi bi-house me-2"></i> Back to Dashboard
        </a>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card print-area border-0">
            <div class="card-body p-5">
                <!-- Clinic Header -->
                <!-- Clinic Header -->
                <?php
                    $facility = $prescription->facility_snapshot ?? ($prescription->doctor->facility ? $prescription->doctor->facility->toArray() : null);
                ?>

                <div class="prescription-header text-center">
                    <?php if($facility): ?>
                        <div class="d-flex align-items-center justify-content-center mb-3">
                            <?php if(!empty($facility['logo_path'])): ?>
                                <img src="<?php echo e(asset('public/storage/' . $facility['logo_path'])); ?>" alt="Logo" class="me-3" style="height: 80px; width: auto;">
                            <?php endif; ?>
                            <div class="text-start">
                                <h1 class="clinic-name mb-0" style="font-size: 2.2rem;"><?php echo e($facility['name']); ?></h1>
                                <p class="mb-0 text-muted small"><?php echo e($facility['type']); ?> | License: <?php echo e($facility['license_number'] ?? 'N/A'); ?></p>
                            </div>
                        </div>
                        <p class="mb-0"><?php echo e($facility['address']); ?>, <?php echo e($facility['district']); ?>, <?php echo e($facility['province']); ?></p>
                        <p class="mb-0 text-muted">Phone: <?php echo e($facility['phone']); ?> <?php if(!empty($facility['email'])): ?> | Email: <?php echo e($facility['email']); ?> <?php endif; ?></p>
                    <?php else: ?>
                        <!-- Fallback / Generic Header -->
                        <div class="clinic-name mb-1">
                            <i class="bi bi-hospital"></i> Medical Clinic
                        </div>
                        <p class="mb-0 text-muted">Address: Medical Plaza, Central City | Phone: +1 234 567 8900</p>
                    <?php endif; ?>
                    
                    <hr class="my-3 mx-auto" style="width: 80%;">
                    
                    <p class="mb-0 fw-bold fs-5 text-dark">Dr. <?php echo e($prescription->doctor->name); ?></p>
                    <?php if($prescription->doctor->specialization || $prescription->doctor->qualification): ?>
                        <p class="mb-0 text-muted">
                            <?php echo e($prescription->doctor->qualification); ?>

                            <?php if($prescription->doctor->specialization && $prescription->doctor->qualification): ?> | <?php endif; ?>
                            <?php echo e($prescription->doctor->specialization); ?>

                        </p>
                    <?php endif; ?>
                </div>

                <!-- Prescription Details -->
                <div class="row mb-4">
                    <div class="col-6">
                        <p class="mb-1"><strong>Prescription ID:</strong> <?php echo e($prescription->prescription_number); ?></p>
                        <p class="mb-1"><strong>Date & Time:</strong> <?php echo e($prescription->created_at->format('d M Y, h:i A')); ?></p>
                    </div>
                    <div class="col-6 text-end">
                        <p class="mb-1"><strong>Patient ID:</strong> <?php echo e($prescription->patient->patient_number); ?></p>
                    </div>
                </div>

                <!-- Patient Information -->
                <div class="border rounded-3 p-4 mb-4" style="background-color: #f8f9fa;">
                    <h6 class="mb-3 text-primary fw-bold">
                        <i class="bi bi-person-circle"></i> Patient Details
                    </h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-2"><strong>Name:</strong> <?php echo e($prescription->patient->name); ?></p>
                            <p class="mb-2"><strong>Age/Gender:</strong> <?php echo e($prescription->patient->age); ?> years | <?php echo e($prescription->patient->gender); ?></p>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <p class="mb-2"><strong>Phone:</strong> <?php echo e($prescription->patient->phone); ?></p>
                            <?php if($prescription->patient->address): ?>
                                <p class="mb-0"><strong>Address:</strong> <?php echo e($prescription->patient->address); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Diagnosis -->
                <div class="mb-4">
                    <h6 class="mb-2 text-primary fw-bold">
                        <i class="bi bi-clipboard2-pulse"></i> Diagnosis
                    </h6>
                    <div class="border rounded-3 p-3 bg-white"><?php echo e($prescription->diagnosis); ?></div>
                </div>

                <!-- Medicines -->
                <div class="mb-4">
                    <h6 class="mb-3 text-primary fw-bold">
                        <i class="bi bi-capsule"></i> RX Medications
                    </h6>
                    <table class="table table-bordered align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th width="30%">Medicine</th>
                                <th width="10%">Type</th>
                                <th width="15%">Dosage</th>
                                <th width="15%">Duration</th>
                                <th width="30%">Instructions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $prescription->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($item->medicine->name); ?></strong></td>
                                <td><span class="badge bg-light text-dark fw-normal"><?php echo e(ucfirst($item->type)); ?></span></td>
                                <td><?php echo e($item->dosage); ?></td>
                                <td><?php echo e($item->duration); ?></td>
                                <td><?php echo e($item->instructions); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Additional Notes -->
                <?php if($prescription->notes): ?>
                <div class="mb-4">
                    <h6 class="mb-2 text-primary fw-bold">
                        <i class="bi bi-sticky"></i> Additional Advice/Notes
                    </h6>
                    <div class="border rounded-3 p-3 bg-white" style="white-space: pre-line;"><?php echo e($prescription->notes); ?></div>
                </div>
                <?php endif; ?>

                <!-- Doctor Signature Section -->
                <div class="row mt-5 pt-4">
                    <div class="col-6">
                        <p class="small text-muted mb-0">Registered Doctor ID: <?php echo e(str_pad($prescription->doctor->id, 5, '0', STR_PAD_LEFT)); ?></p>
                    </div>
                    <div class="col-6 text-end">
                        <div class="d-inline-block text-center mt-4">
                            <div style="border-top: 2px solid #333; width: 220px;">
                                <p class="mt-2 mb-0 fw-bold">Dr. <?php echo e($prescription->doctor->name); ?></p>
                                <small class="text-muted">Digital Signature Verified</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <div class="text-center mt-5 pt-4 border-top">
                    <small class="text-muted">
                        This document is a computer-generated prescription intended for medical use. 
                        Valid only if signed or authenticated by registered personnel.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/doctor/prescriptions/print.blade.php ENDPATH**/ ?>