

<?php $__env->startSection('title', 'Doctors'); ?>
<?php $__env->startSection('page-title', 'Doctor Management'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Doctors</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">All Doctors</h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('admin.doctors.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Add New Doctor
                    </a>
                </div>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Specialization</th>
                            <th>Facility</th>
                            <th>Patients</th>
                            <th>Prescriptions</th>
                            <th>Created at</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(str_pad($doctor->id, 4, '0', STR_PAD_LEFT)); ?></td>
                            <td><strong><?php echo e($doctor->name); ?></strong></td>
                            <td><?php echo e($doctor->email); ?></td>
                            <td><?php echo e($doctor->specialization ?? 'General'); ?></td>
                            <td>
                                <?php if($doctor->facility): ?>
                                    <?php echo e($doctor->facility->name); ?> <br>
                                    <small class="text-muted"><?php echo e($doctor->facility->type); ?></small>
                                <?php else: ?>
                                    <span class="text-muted small">Not Assigned</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge badge-primary"><?php echo e($doctor->patients_count); ?></span></td>
                            <td><span class="badge badge-success"><?php echo e($doctor->prescriptions_count); ?></span></td>
                            <td><?php echo e($doctor->created_at->format('d M Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.doctors.edit', $doctor->id)); ?>" 
                                   class="btn btn-sm btn-warning" 
                                   title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.doctors.destroy', $doctor->id)); ?>" 
                                      method="POST" 
                                      class="d-inline"
                                      onsubmit="return confirm('Are you sure you want to delete this doctor? This may affect associated data.');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">No doctors registered yet.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer clearfix">
                <?php echo e($doctors->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/admin/doctors/index.blade.php ENDPATH**/ ?>