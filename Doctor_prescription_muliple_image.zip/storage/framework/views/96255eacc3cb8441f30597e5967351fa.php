

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-6">
            <h1 class="h3 mb-0 text-gray-800">Facilities</h1>
        </div>
        <div class="col-6 text-end">
            <a href="<?php echo e(route('admin.facilities.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add New Facility
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" width="100%" cellspacing="0">
                    <thead class="table-light">
                        <tr>
                            <th>Logo</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Province/District</th>
                            <th>Contact</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center">
                                <?php if($facility->logo_path): ?>
                                    <img src="<?php echo e(asset('public/storage/' . $facility->logo_path)); ?>?v=<?php echo e(time()); ?>" alt="Logo" class="img-thumbnail" style="height: 50px;">
                                <?php else: ?>
                                    <span class="badge bg-secondary">No Logo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-bold"><?php echo e($facility->name); ?></div>
                                <small class="text-muted">Lic: <?php echo e($facility->license_number); ?></small>
                            </td>
                            <td><?php echo e($facility->type); ?></td>
                            <td>
                                <div><?php echo e($facility->province); ?></div>
                                <small class="text-muted"><?php echo e($facility->district); ?></small>
                            </td>
                            <td>
                                <div><i class="fas fa-phone me-1"></i> <?php echo e($facility->phone); ?></div>
                                <?php if($facility->email): ?>
                                    <div><i class="fas fa-envelope me-1"></i> <?php echo e($facility->email); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($facility->status): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('admin.facilities.edit', $facility)); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.facilities.destroy', $facility)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">No facilities found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/admin/facilities/index.blade.php ENDPATH**/ ?>