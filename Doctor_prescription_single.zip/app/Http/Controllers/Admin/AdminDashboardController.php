<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use App\Models\Prescription;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $totalPatients = Patient::count();
        $totalPrescriptions = Prescription::count();
        $recentPrescriptions = Prescription::with('patient')
            ->latest()
            ->take(10)
            ->get();

        return view('admin.dashboard', compact('totalPatients', 'totalPrescriptions', 'recentPrescriptions'));
    }
}
