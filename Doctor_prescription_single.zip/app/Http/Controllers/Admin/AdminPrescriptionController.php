<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Prescription;
use Illuminate\Http\Request;

class AdminPrescriptionController extends Controller
{
    public function index()
    {
        $prescriptions = Prescription::with('patient')
            ->latest()
            ->paginate(20);

        return view('admin.prescriptions.index', compact('prescriptions'));
    }

    public function show($id)
    {
        $prescription = Prescription::with(['patient', 'items.medicine'])
            ->findOrFail($id);

        return view('admin.prescriptions.show', compact('prescription'));
    }

    public function destroy($id)
    {
        $prescription = Prescription::findOrFail($id);
        $prescription->delete();

        return redirect()->route('admin.prescriptions.index')
            ->with('success', 'Prescription deleted successfully');
    }
}
