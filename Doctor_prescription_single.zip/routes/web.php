<?php

use App\Http\Controllers\PublicPrescriptionController;
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\AdminDashboardController;
use App\Http\Controllers\Admin\AdminPatientController;
use App\Http\Controllers\Admin\AdminPrescriptionController;
use App\Http\Controllers\Admin\AdminMedicineController;
use App\Http\Controllers\Admin\AdminPrescriptionDefaultsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Public Doctor Frontend Routes (No Authentication)
Route::get('/', [PublicPrescriptionController::class, 'index'])->name('home');
Route::post('/search-patient', [PublicPrescriptionController::class, 'searchPatient'])->name('patient.search');
Route::get('/prescription/create/{patientId?}', [PublicPrescriptionController::class, 'createPrescriptionForm'])->name('prescription.create');
Route::post('/prescription/store', [PublicPrescriptionController::class, 'storePrescription'])->name('prescription.store');
Route::get('/prescription/print/{id}', [PublicPrescriptionController::class, 'printPrescription'])->name('prescription.print');
Route::get('/patient/history/{id}', [PublicPrescriptionController::class, 'patientHistory'])->name('patient.history');

// Admin Authentication Routes
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login', [AdminAuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('login.post');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

    // Protected Admin Routes
    Route::middleware('auth:admin')->group(function () {
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');
        
        // Patients Management
        Route::get('/patients', [AdminPatientController::class, 'index'])->name('patients.index');
        Route::get('/patients/{id}', [AdminPatientController::class, 'show'])->name('patients.show');
        Route::get('/patients/{id}/edit', [AdminPatientController::class, 'edit'])->name('patients.edit');
        Route::put('/patients/{id}', [AdminPatientController::class, 'update'])->name('patients.update');
        Route::delete('/patients/{id}', [AdminPatientController::class, 'destroy'])->name('patients.destroy');
        
        // Prescriptions Management
        Route::get('/prescriptions', [AdminPrescriptionController::class, 'index'])->name('prescriptions.index');
        Route::get('/prescriptions/{id}', [AdminPrescriptionController::class, 'show'])->name('prescriptions.show');
        Route::delete('/prescriptions/{id}', [AdminPrescriptionController::class, 'destroy'])->name('prescriptions.destroy');

        // Medicines Management
        Route::resource('medicines', AdminMedicineController::class);

        // Default Notes Management
        Route::resource('defaults', AdminPrescriptionDefaultsController::class);
    });
});
