@extends('admin.layouts.admin')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('breadcrumb')
    <li class="breadcrumb-item active">Dashboard</li>
@endsection

@section('content')
<div class="row">
    <!-- Total Patients -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner">
                <h3>{{ $totalPatients }}</h3>
                <p>Total Patients</p>
            </div>
            <div class="icon">
                <i class="fas fa-users"></i>
            </div>
            <a href="{{ route('admin.patients.index') }}" class="small-box-footer">
                View All <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <!-- Total Prescriptions -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3>{{ $totalPrescriptions }}</h3>
                <p>Total Prescriptions</p>
            </div>
            <div class="icon">
                <i class="fas fa-file-prescription"></i>
            </div>
            <a href="{{ route('admin.prescriptions.index') }}" class="small-box-footer">
                View All <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <!-- Today's Prescriptions -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3>{{ $recentPrescriptions->where('created_at', '>=', now()->startOfDay())->count() }}</h3>
                <p>Today's Prescriptions</p>
            </div>
            <div class="icon">
                <i class="fas fa-calendar-day"></i>
            </div>
            <a href="{{ route('admin.prescriptions.index') }}" class="small-box-footer">
                More info <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <!-- Quick Action -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-danger">
            <div class="inner">
                <h3>Quick</h3>
                <p>Create Prescription</p>
            </div>
            <div class="icon">
                <i class="fas fa-plus-circle"></i>
            </div>
            <a href="{{ route('prescription.create') }}" target="_blank" class="small-box-footer">
                Go <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
</div>

<!-- Recent Prescriptions -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-list"></i> Recent Prescriptions
                </h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>Prescription No</th>
                            <th>Patient</th>
                            <th>Diagnosis</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($recentPrescriptions as $prescription)
                        <tr>
                            <td>{{ $prescription->prescription_number }}</td>
                            <td>
                                <a href="{{ route('admin.patients.show', $prescription->patient->id) }}">
                                    {{ $prescription->patient->name }}
                                </a>
                            </td>
                            <td>{{ Str::limit($prescription->diagnosis, 50) }}</td>
                            <td>{{ $prescription->created_at->format('d M Y, h:i A') }}</td>
                            <td>
                                <a href="{{ route('admin.prescriptions.show', $prescription->id) }}" 
                                   class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="{{ route('prescription.print', $prescription->id) }}" 
                                   class="btn btn-sm btn-primary" 
                                   target="_blank">
                                    <i class="fas fa-print"></i>
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center">No prescriptions found</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
