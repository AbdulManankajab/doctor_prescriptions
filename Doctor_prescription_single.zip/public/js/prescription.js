$(document).ready(function () {
    // Add medicine row
    $('#add-medicine').click(function () {
        const rowCount = $('.medicine-row').length;
        const newRow = $('.medicine-row:first').clone();

        // Reset inputs and update names
        newRow.find('select').each(function () {
            const name = $(this).attr('name');
            if (name) {
                $(this).attr('name', name.replace(/\[\d+\]/, '[' + rowCount + ']'));
            }
            $(this).val($(this).find('option:first').val());
        });

        // Specific reset for dosage
        newRow.find('.medicine-dosage').html('<option value="">Dosage</option>');

        // Add row to container
        $('#medicinesContainer').append(newRow);

        // Show all remove buttons
        $('.remove-medicine').show();
    });

    // Remove medicine row
    $(document).on('click', '.remove-medicine', function () {
        if ($('.medicine-row').length > 1) {
            $(this).closest('.medicine-row').remove();
            updateRowIndices();

            // Hide remove button if only one row left
            if ($('.medicine-row').length === 1) {
                $('.remove-medicine').hide();
            }
        }
    });

    // Handle medicine selection change
    $(document).on('change', '.medicine-select', function () {
        const row = $(this).closest('.medicine-row');
        const select = this; // The <select> element
        const selectedOption = select.options[select.selectedIndex];

        if (!selectedOption || !selectedOption.value) {
            row.find('.medicine-dosage').html('<option value="">Dosage</option>');
            return;
        }

        // Extremely robust data attribute reading
        const type = selectedOption.getAttribute('data-type') || $(selectedOption).data('type');
        const dosages = selectedOption.getAttribute('data-dosages') || $(selectedOption).data('dosages');

        console.log('Medicine ID:', selectedOption.value, 'Name:', selectedOption.text.trim());
        console.log('Type found:', type, 'Dosages found:', dosages);

        if (type) {
            row.find('.medicine-type').val(type);
        }

        const dosageSelect = row.find('.medicine-dosage');
        dosageSelect.empty();
        dosageSelect.append('<option value="">Dosage</option>');

        if (dosages && dosages.trim() !== "") {
            const dosageArray = dosages.toString().split(',').map(s => s.trim());
            console.log('Parsed dosage array:', dosageArray);

            dosageArray.forEach(d => {
                if (d) {
                    const opt = document.createElement('option');
                    opt.value = d;
                    opt.text = d;
                    dosageSelect[0].add(opt);
                }
            });

            if (dosageArray.length === 1 && dosageArray[0]) {
                dosageSelect.val(dosageArray[0]);
            }
        } else {
            console.warn('No dosages available for medicine:', selectedOption.text.trim());
            // Optionally add a manual input if we want, but for now just leave it empty
            dosageSelect.append('<option value="As directed">As directed</option>');
        }
    });

    // Handle default notes buttons
    $(document).on('click', '.default-note-btn', function () {
        const noteText = $(this).data('text');
        const notesTextArea = $('#notes');
        const currentText = notesTextArea.val();

        if (currentText) {
            notesTextArea.val(currentText + '\n' + noteText);
        } else {
            notesTextArea.val(noteText);
        }
    });

    // Function to update indices after removal
    function updateRowIndices() {
        $('.medicine-row').each(function (index) {
            $(this).find('select').each(function () {
                const name = $(this).attr('name');
                if (name) {
                    const newName = name.replace(/medicines\[\d+\]/, 'medicines[' + index + ']');
                    $(this).attr('name', newName);
                }
            });
        });
    }
});
