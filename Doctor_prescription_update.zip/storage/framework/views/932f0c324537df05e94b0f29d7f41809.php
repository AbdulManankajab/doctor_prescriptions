

<?php $__env->startSection('title', 'Prescription Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-10 mx-auto">
        <div class="mb-3 d-flex justify-content-between align-items-center">
            <a href="<?php echo e(route('doctor.dashboard')); ?>" class="text-decoration-none text-muted">
                <i class="bi bi-arrow-left me-1"></i> Back to Dashboard
            </a>
            <div class="btn-group">
                <a href="<?php echo e(route('doctor.prescriptions.print', $prescription->id)); ?>" target="_blank" class="btn btn-outline-primary shadow-none">
                    <i class="bi bi-printer me-1"></i> Print
                </a>
                <a href="<?php echo e(route('doctor.patient.history', $prescription->patient_id)); ?>" class="btn btn-outline-info shadow-none">
                    <i class="bi bi-clock-history me-1"></i> History
                </a>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white p-4 border-0 d-flex justify-content-between align-items-center">
                <h4 class="fw-bold mb-0">
                    Prescription <span class="text-primary">#<?php echo e($prescription->prescription_number); ?></span>
                </h4>
                <div>
                    <?php if($prescription->status === 'draft'): ?>
                        <span class="badge bg-secondary px-3 py-2 rounded-pill">Draft</span>
                    <?php elseif($prescription->status === 'sent'): ?>
                        <span class="badge bg-warning text-dark px-3 py-2 rounded-pill">Sent to Pharmacy</span>
                    <?php elseif($prescription->status === 'dispensed'): ?>
                        <span class="badge bg-success px-3 py-2 rounded-pill">Dispensed</span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card-body p-4 pt-0">
                <hr class="mt-0 mb-4">
                
                <div class="row mb-4">
                    <div class="col-md-5">
                        <h6 class="text-muted small fw-bold text-uppercase mb-3">Patient Information</h6>
                        <p class="mb-1"><span class="fw-semibold">Name:</span> <?php echo e($prescription->patient->name); ?></p>
                        <p class="mb-1"><span class="fw-semibold">Age/Gender:</span> <?php echo e($prescription->patient->age); ?>Y / <?php echo e($prescription->patient->gender); ?></p>
                        <p class="mb-1"><span class="fw-semibold">Phone:</span> <?php echo e($prescription->patient->phone); ?></p>
                    </div>
                    <div class="col-md-5">
                        <h6 class="text-muted small fw-bold text-uppercase mb-3">Submission Details</h6>
                        <p class="mb-1"><span class="fw-semibold">Created At:</span> <?php echo e($prescription->created_at->format('d M Y, h:i A')); ?></p>
                        <?php if($prescription->sent_at): ?>
                            <p class="mb-1"><span class="fw-semibold">Sent to Pharmacy:</span> <?php echo e($prescription->sent_at->format('d M Y, h:i A')); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-2 text-end">
                        <?php if($prescription->qr_token): ?>
                            <div class="d-inline-block p-1 border rounded bg-white shadow-sm">
                                <?php echo SimpleSoftwareIO\QrCode\Facades\QrCode::size(100)->generate($prescription->qr_token); ?>

                            </div>
                            <div style="font-size: 8px; margin-top: 5px; color: #888;" class="text-center">SECURE QR</div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-4">
                    <h6 class="text-muted small fw-bold text-uppercase mb-3">Diagnosis</h6>
                    <div class="p-3 bg-light rounded-3">
                        <?php echo e($prescription->diagnosis); ?>

                    </div>
                </div>

                <div class="mb-4">
                    <h6 class="text-muted small fw-bold text-uppercase mb-3">Medications</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th>Medicine</th>
                                    <th>Type</th>
                                    <th>Dosage</th>
                                    <th>Duration</th>
                                    <th>Instructions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $prescription->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="fw-semibold"><?php echo e($item->medicine->name); ?></td>
                                        <td><?php echo e(ucfirst($item->type)); ?></td>
                                        <td><?php echo e($item->dosage); ?></td>
                                        <td><?php echo e($item->duration); ?></td>
                                        <td><?php echo e($item->instructions); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php if($prescription->notes): ?>
                <div class="mb-4">
                    <h6 class="text-muted small fw-bold text-uppercase mb-3">Additional Instructions</h6>
                    <div class="p-3 border-start border-4 border-primary bg-light" style="white-space: pre-line;"><?php echo e($prescription->notes); ?></div>
                </div>
                <?php endif; ?>
            </div>

            <?php if($prescription->status === 'draft'): ?>
            <div class="card-footer bg-white p-4 border-0">
                <form action="<?php echo e(route('doctor.prescriptions.send', $prescription->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success w-100 rounded-pill py-2" onclick="return confirm('Send to Hospital Pharmacy?')">
                        <i class="bi bi-send me-2"></i> Send to Pharmacy
                    </button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/doctor/prescriptions/show.blade.php ENDPATH**/ ?>