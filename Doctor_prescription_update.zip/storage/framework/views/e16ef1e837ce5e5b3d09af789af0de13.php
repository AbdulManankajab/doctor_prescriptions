

<?php $__env->startSection('title', 'Pharmacy Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0">Pending Prescriptions</h4>
                    <div class="d-flex align-items-center" style="gap: 10px;">
                        <form action="<?php echo e(route('pharmacy.dashboard')); ?>" method="GET" class="d-flex" style="max-width: 400px;">
                            <input type="text" name="search" class="form-control me-2" placeholder="Search PR #..." value="<?php echo e(request('search')); ?>">
                            <button type="submit" class="btn btn-pharmacy"><i class="bi bi-search"></i></button>
                        </form>
                        <a href="<?php echo e(route('scan.index')); ?>" class="btn btn-teal text-white" style="background-color: #0d9488;">
                            <i class="bi bi-qr-code-scan"></i> Scan
                        </a>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th>PR #</th>
                                <th>Patient</th>
                                <th>Doctor</th>
                                <th>Status</th>
                                <th>Sent At</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><span class="fw-bold"><?php echo e($prescription->prescription_number); ?></span></td>
                                    <td><?php echo e($prescription->patient->name); ?></td>
                                    <td><?php echo e($prescription->doctor->name); ?></td>
                                    <td>
                                        <?php if($prescription->status === 'sent'): ?>
                                            <span class="badge bg-warning text-dark">Ready to Dispense</span>
                                        <?php elseif($prescription->status === 'dispensed'): ?>
                                            <span class="badge bg-success">Dispensed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($prescription->sent_at ? $prescription->sent_at->format('d M Y, h:i A') : 'N/A'); ?></td>
                                    <td class="text-end">
                                        <a href="<?php echo e(route('pharmacy.prescriptions.show', $prescription->id)); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                            <i class="bi bi-eye me-1"></i> View
                                        </a>
                                        <?php if($prescription->status === 'sent'): ?>
                                            <form action="<?php echo e(route('pharmacy.prescriptions.dispense', $prescription->id)); ?>" method="POST" class="d-inline ml-2">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-success rounded-pill px-3" onclick="return confirm('Mark as dispensed?')">
                                                    <i class="bi bi-check-circle me-1"></i> Dispense
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <i class="bi bi-inbox text-muted fs-1 mb-3 d-block"></i>
                                        <p class="text-muted">No prescriptions found.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($prescriptions->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pharmacy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/pharmacy/dashboard.blade.php ENDPATH**/ ?>