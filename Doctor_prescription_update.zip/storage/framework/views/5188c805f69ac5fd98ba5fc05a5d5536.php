<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Pharmacy Panel'); ?> - Prescription System</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root {
            --pharmacy-primary: #0d9488;
            --pharmacy-gradient: linear-gradient(135deg, #0d9488 0%, #065f46 100%);
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }
        
        .navbar {
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            background: #fff !important;
        }
 
        .main-wrapper {
            padding-top: 20px;
            padding-bottom: 40px;
        }
        
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
        
        .btn-pharmacy {
            background: var(--pharmacy-gradient);
            color: white;
            border: none;
            box-shadow: 0 4px 12px rgba(13, 148, 136, 0.3);
        }
        
        .btn-pharmacy:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 15px rgba(13, 148, 136, 0.4);
            color: white;
        }

        .nav-link.active {
            font-weight: 600;
            color: var(--pharmacy-primary) !important;
        }

        .text-pharmacy {
            color: var(--pharmacy-primary) !important;
        }

        @media print {
            .no-print { display: none !important; }
            body { background: white; }
        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light sticky-top no-print">
        <div class="container">
            <a class="navbar-brand fw-bold text-pharmacy" href="<?php echo e(route('pharmacy.dashboard')); ?>">
                <i class="bi bi-capsule"></i> Hospital Pharmacy
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#pharmacyNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="pharmacyNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('pharmacy.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('pharmacy.dashboard')); ?>">
                            <i class="bi bi-speedometer2 me-1"></i> Dashboard
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> <?php echo e(Auth::guard('pharmacy')->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                            <li>
                                <form action="<?php echo e(route('pharmacy.logout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-wrapper">
        <?php if(session('success')): ?>
            <div class="alert alert-success border-0 shadow-sm mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger border-0 shadow-sm mb-4">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/layouts/pharmacy.blade.php ENDPATH**/ ?>