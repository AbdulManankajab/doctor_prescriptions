<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use App\Models\Prescription;
use App\Models\Doctor;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $totalDoctors = Doctor::count();
        $totalPatients = Patient::count();
        $totalPrescriptions = Prescription::count();
        $recentPrescriptions = Prescription::with(['patient', 'doctor'])
            ->latest()
            ->take(10)
            ->get();

        return view('admin.dashboard', compact('totalDoctors', 'totalPatients', 'totalPrescriptions', 'recentPrescriptions'));
    }
}
