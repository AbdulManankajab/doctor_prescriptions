

<?php $__env->startSection('title', 'Print Prescription'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    @media print {
        @page {
            size: A4;
            margin: 15mm;
        }
        
        body {
            background: white !important;
        }
        
        .print-area {
            width: 100%;
            max-width: 100%;
        }
    }
    
    .prescription-header {
        border-bottom: 3px solid #667eea;
        margin-bottom: 20px;
        padding-bottom: 15px;
    }
    
    .clinic-name {
        font-size: 2rem;
        font-weight: bold;
        color: #667eea;
    }
    
    .prescription-table {
        border: 2px solid #dee2e6;
    }
    
    .prescription-table th {
        background-color: #f8f9fa;
        font-weight: 600;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row no-print mb-3">
        <div class="col-12">
            <button onclick="window.print()" class="btn btn-primary btn-lg">
                <i class="bi bi-printer"></i> Print Prescription
            </button>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary btn-lg">
                <i class="bi bi-house"></i> Back to Home
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card print-area">
                <div class="card-body p-5">
                    <!-- Clinic Header -->
                    <div class="prescription-header text-center">
                        <div class="clinic-name">
                            <i class="bi bi-hospital"></i> Medical Clinic
                        </div>
                        <p class="mb-0 text-muted">Address: Your Clinic Address Here | Phone: +1234567890</p>
                    </div>

                    <!-- Prescription Header -->
                    <div class="row mb-4">
                        <div class="col-6">
                            <p class="mb-1"><strong>Prescription No:</strong> <?php echo e($prescription->prescription_number); ?></p>
                            <p class="mb-1"><strong>Date:</strong> <?php echo e($prescription->created_at->format('d M Y, h:i A')); ?></p>
                        </div>
                        <div class="col-6 text-end">
                            <p class="mb-1"><strong>Patient No:</strong> <?php echo e($prescription->patient->patient_number); ?></p>
                        </div>
                    </div>

                    <!-- Patient Information -->
                    <div class="border rounded p-3 mb-4" style="background-color: #f8f9fa;">
                        <h5 class="mb-3">
                            <i class="bi bi-person"></i> Patient Information
                        </h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p class="mb-2"><strong>Name:</strong> <?php echo e($prescription->patient->name); ?></p>
                                <p class="mb-2"><strong>Age:</strong> <?php echo e($prescription->patient->age); ?> years</p>
                            </div>
                            <div class="col-md-6">
                                <p class="mb-2"><strong>Gender:</strong> <?php echo e($prescription->patient->gender); ?></p>
                                <p class="mb-2"><strong>Phone:</strong> <?php echo e($prescription->patient->phone); ?></p>
                            </div>
                            <?php if($prescription->patient->address): ?>
                            <div class="col-12">
                                <p class="mb-0"><strong>Address:</strong> <?php echo e($prescription->patient->address); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Diagnosis -->
                    <div class="mb-4">
                        <h5 class="mb-2">
                            <i class="bi bi-clipboard2-pulse"></i> Diagnosis
                        </h5>
                        <p class="border rounded p-3 mb-0"><?php echo e($prescription->diagnosis); ?></p>
                    </div>

                    <!-- Medicines -->
                    <div class="mb-4">
                        <h5 class="mb-3">
                            <i class="bi bi-capsule"></i> Prescribed Medicines
                        </h5>
                        <table class="table table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th>Medicine</th>
                                    <th>Type</th>
                                    <th>Dosage</th>
                                    <th>Duration</th>
                                    <th>Instructions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $prescription->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong><?php echo e($item->medicine->name); ?></strong></td>
                                    <td><?php echo e(ucfirst($item->type)); ?></td>
                                    <td><?php echo e($item->dosage); ?></td>
                                    <td><?php echo e($item->duration); ?></td>
                                    <td><?php echo e($item->instructions); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Notes -->
                    <?php if($prescription->notes): ?>
                    <div class="mb-4">
                        <h5 class="mb-2">
                            <i class="bi bi-sticky"></i> Additional Notes
                        </h5>
                        <p class="border rounded p-3 mb-0"><?php echo e($prescription->notes); ?></p>
                    </div>
                    <?php endif; ?>

                    <!-- Doctor Signature -->
                    <div class="mt-5 pt-4 text-end">
                        <div style="border-top: 2px solid #000; width: 200px; margin-left: auto; margin-top: 60px;">
                            <p class="mb-0 mt-2"><strong>Doctor's Signature</strong></p>
                        </div>
                    </div>

                    <!-- Footer -->
                    <div class="text-center mt-5 pt-3" style="border-top: 1px solid #dee2e6;">
                        <small class="text-muted">
                            This is a computer-generated prescription. For any queries, please contact the clinic.
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/public/prescription-print.blade.php ENDPATH**/ ?>