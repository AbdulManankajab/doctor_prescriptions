

<?php $__env->startSection('title', 'Prescriptions'); ?>
<?php $__env->startSection('page-title', 'Prescriptions Management'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Prescriptions</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title">All Prescriptions</h3>
            </div>
            <div class="card-body bg-light border-bottom">
                <form action="<?php echo e(route('admin.prescriptions.index')); ?>" method="GET" class="row g-3">
                    <div class="col-md-4">
                        <select name="doctor_id" class="form-control select2" onchange="this.form.submit()">
                            <option value="">All Doctors</option>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($doctor->id); ?>" <?php echo e(request('doctor_id') == $doctor->id ? 'selected' : ''); ?>>
                                    <?php echo e($doctor->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('admin.prescriptions.index')); ?>" class="btn btn-default">Reset</a>
                    </div>
                </form>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>Prescription No</th>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Diagnosis</th>
                            <th>Medicines</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($prescription->prescription_number); ?></td>
                            <td>
                                <?php echo e($prescription->patient->name); ?>

                                <br>
                                <small class="text-muted"><?php echo e($prescription->patient->patient_number); ?></small>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo e($prescription->doctor->name ?? 'System'); ?></span>
                                <br>
                                <small class="text-xs"><?php echo e($prescription->doctor->specialization ?? ''); ?></small>
                            </td>
                            <td><?php echo e(Str::limit($prescription->diagnosis, 30)); ?></td>
                            <td>
                                <span class="badge badge-success"><?php echo e($prescription->items->count()); ?></span>
                            </td>
                            <td><?php echo e($prescription->created_at->format('d M Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.prescriptions.show', $prescription->id)); ?>" 
                                   class="btn btn-sm btn-info" 
                                   title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.prescriptions.print', $prescription->id)); ?>" 
                                   class="btn btn-sm btn-primary" 
                                   target="_blank" 
                                   title="Print">
                                    <i class="fas fa-print"></i>
                                </a>
                                <form action="<?php echo e(route('admin.prescriptions.destroy', $prescription->id)); ?>" 
                                      method="POST" 
                                      class="d-inline"
                                      onsubmit="return confirm('Are you sure you want to delete this prescription?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No prescriptions found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer clearfix">
                <?php echo e($prescriptions->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/admin/prescriptions/index.blade.php ENDPATH**/ ?>