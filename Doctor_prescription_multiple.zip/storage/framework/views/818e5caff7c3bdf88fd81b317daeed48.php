

<?php $__env->startSection('title', 'Patient History'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">
                        <i class="bi bi-clock-history"></i> Patient Prescription History
                    </h3>
                </div>
                <div class="card-body">
                    <!-- Patient Info -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <p class="mb-2"><strong>Name:</strong> <?php echo e($patient->name); ?></p>
                            <p class="mb-2"><strong>Patient Number:</strong> <?php echo e($patient->patient_number); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-2"><strong>Age/Gender:</strong> <?php echo e($patient->age); ?> years / <?php echo e($patient->gender); ?></p>
                            <p class="mb-2"><strong>Phone:</strong> <?php echo e($patient->phone); ?></p>
                        </div>
                    </div>

                    <hr>

                    <!-- Prescriptions -->
                    <h5 class="mb-3">Prescription History (<?php echo e($patient->prescriptions->count()); ?> total)</h5>
                    
                    <?php if($patient->prescriptions->count() > 0): ?>
                        <div class="accordion" id="prescriptionAccordion">
                            <?php $__currentLoopData = $patient->prescriptions->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button <?php echo e($index > 0 ? 'collapsed' : ''); ?>" 
                                            type="button" 
                                            data-bs-toggle="collapse" 
                                            data-bs-target="#prescription<?php echo e($prescription->id); ?>">
                                        <strong><?php echo e($prescription->prescription_number); ?></strong> 
                                        &nbsp;-&nbsp; <?php echo e($prescription->created_at->format('d M Y, h:i A')); ?>

                                        &nbsp;<span class="badge bg-primary"><?php echo e($prescription->items->count()); ?> medicines</span>
                                    </button>
                                </h2>
                                <div id="prescription<?php echo e($prescription->id); ?>" 
                                     class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?>" 
                                     data-bs-parent="#prescriptionAccordion">
                                    <div class="accordion-body">
                                        <p><strong>Diagnosis:</strong> <?php echo e($prescription->diagnosis); ?></p>
                                        
                                        <?php if($prescription->notes): ?>
                                        <p><strong>Notes:</strong> <?php echo e($prescription->notes); ?></p>
                                        <?php endif; ?>

                                        <h6 class="mt-3 mb-2">Medicines:</h6>
                                                <table class="table table-sm table-bordered mt-2">
                                                    <thead>
                                                        <tr class="table-light">
                                                            <th>Medicine</th>
                                                            <th>Type</th>
                                                            <th>Dosage</th>
                                                            <th>Duration</th>
                                                            <th>Instructions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $prescription->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($item->medicine->name); ?></td>
                                                            <td><?php echo e(ucfirst($item->type)); ?></td>
                                                            <td><?php echo e($item->dosage); ?></td>
                                                            <td><?php echo e($item->duration); ?></td>
                                                            <td><?php echo e($item->instructions); ?></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                        <a href="<?php echo e(route('prescription.print', $prescription->id)); ?>" 
                                           class="btn btn-sm btn-primary" 
                                           target="_blank">
                                            <i class="bi bi-printer"></i> Print
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No prescriptions found for this patient.
                        </div>
                    <?php endif; ?>

                    <div class="mt-4">
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left"></i> Back to Home
                        </a>
                        <a href="<?php echo e(route('prescription.create', $patient->id)); ?>" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> New Prescription
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/public/patient-history.blade.php ENDPATH**/ ?>