

<?php $__env->startSection('title', 'Edit Medicine'); ?>
<?php $__env->startSection('page-title', 'Edit Medicine'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title">Update Medicine Details</h3>
            </div>
            <form action="<?php echo e(route('admin.medicines.update', $medicine->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label for="name">Medicine Name</label>
                        <input type="text" name="name" class="form-control" id="name" value="<?php echo e($medicine->name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="type">Type</label>
                        <select name="type" class="form-control" required>
                            <option value="tablet" <?php echo e($medicine->type == 'tablet' ? 'selected' : ''); ?>>Tablet</option>
                            <option value="syrup" <?php echo e($medicine->type == 'syrup' ? 'selected' : ''); ?>>Syrup</option>
                            <option value="capsule" <?php echo e($medicine->type == 'capsule' ? 'selected' : ''); ?>>Capsule</option>
                            <option value="injection" <?php echo e($medicine->type == 'injection' ? 'selected' : ''); ?>>Injection</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="dosage_options">Dosage Options (comma separated)</label>
                        <input type="text" name="dosage_options" class="form-control" id="dosage_options" value="<?php echo e($medicine->dosage_options); ?>">
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-warning">Update</button>
                    <a href="<?php echo e(route('admin.medicines.index')); ?>" class="btn btn-default">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/admin/medicines/edit.blade.php ENDPATH**/ ?>