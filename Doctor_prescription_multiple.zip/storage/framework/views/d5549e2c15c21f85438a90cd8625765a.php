

<?php $__env->startSection('title', 'Patient History'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card border-0">
            <div class="card-header bg-white p-4 border-0">
                <h3 class="mb-0 fw-bold">
                    <i class="bi bi-clock-history text-primary me-2"></i> Patient Prescription History
                </h3>
            </div>
            <div class="card-body p-4">
                <!-- Patient Info -->
                <div class="row mb-5 g-4">
                    <div class="col-md-6">
                        <div class="p-3 border rounded-3 bg-light h-100">
                            <h6 class="text-muted small text-uppercase fw-bold mb-3">Personal Details</h6>
                            <h4 class="mb-1 fw-bold text-primary"><?php echo e($patient->name); ?></h4>
                            <p class="mb-1"><strong>Patient ID:</strong> <?php echo e($patient->patient_number); ?></p>
                            <p class="mb-0"><strong>Age/Gender:</strong> <?php echo e($patient->age); ?> years / <?php echo e($patient->gender); ?></p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-3 border rounded-3 bg-light h-100">
                            <h6 class="text-muted small text-uppercase fw-bold mb-3">Contact Information</h6>
                            <p class="mb-1"><strong>Phone:</strong> <?php echo e($patient->phone); ?></p>
                            <p class="mb-0"><strong>Address:</strong> <?php echo e($patient->address ?? 'N/A'); ?></p>
                        </div>
                    </div>
                </div>

                <h5 class="mb-4 fw-bold">Recent Visits (<?php echo e($patient->prescriptions->count()); ?>)</h5>
                
                <?php if($patient->prescriptions->count() > 0): ?>
                    <div class="accordion accordion-flush" id="historyAccordion">
                        <?php $__currentLoopData = $patient->prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item border rounded-3 mb-3 overflow-hidden shadow-sm border-0">
                            <h2 class="accordion-header">
                                <button class="accordion-button <?php echo e($index > 0 ? 'collapsed' : ''); ?> bg-white py-3 px-4" 
                                        type="button" 
                                        data-bs-toggle="collapse" 
                                        data-bs-target="#visit<?php echo e($prescription->id); ?>">
                                    <div class="d-flex w-100 justify-content-between align-items-center pe-3">
                                        <div>
                                            <span class="fw-bold fs-5 text-dark"><?php echo e($prescription->prescription_number); ?></span>
                                            <span class="ms-3 text-muted small"><i class="bi bi-calendar3 me-1"></i> <?php echo e($prescription->created_at->format('d M Y')); ?></span>
                                        </div>
                                        <span class="badge bg-primary rounded-pill px-3"><?php echo e($prescription->items->count()); ?> Meds</span>
                                    </div>
                                </button>
                            </h2>
                            <div id="visit<?php echo e($prescription->id); ?>" 
                                 class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?>" 
                                 data-bs-parent="#historyAccordion">
                                <div class="accordion-body p-4 bg-white border-top">
                                    <div class="row mb-4">
                                        <div class="col-md-12">
                                            <h6 class="fw-bold text-primary mb-2">Diagnosis:</h6>
                                            <p class="bg-light p-3 rounded-3 mb-3"><?php echo e($prescription->diagnosis); ?></p>
                                            
                                            <?php if($prescription->notes): ?>
                                                <h6 class="fw-bold text-primary mb-2">Advice & Notes:</h6>
                                                <p class="bg-light p-3 rounded-3" style="white-space: pre-line;"><?php echo e($prescription->notes); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <h6 class="fw-bold text-primary mb-3">Medications List:</h6>
                                    <div class="table-responsive rounded-3">
                                        <table class="table table-bordered align-middle">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Medicine</th>
                                                    <th>Type</th>
                                                    <th>Dosage</th>
                                                    <th>Duration</th>
                                                    <th>Timing</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $prescription->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><strong><?php echo e($item->medicine->name); ?></strong></td>
                                                    <td><?php echo e(ucfirst($item->type)); ?></td>
                                                    <td><?php echo e($item->dosage); ?></td>
                                                    <td><?php echo e($item->duration); ?></td>
                                                    <td><?php echo e($item->instructions); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="text-end mt-4">
                                        <a href="<?php echo e(route('doctor.prescriptions.print', $prescription->id)); ?>" 
                                           class="btn btn-outline-primary px-4 rounded-pill" 
                                           target="_blank">
                                            <i class="bi bi-printer me-2"></i> Print This Version
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info rounded-3 border-0 shadow-sm">
                        <i class="bi bi-info-circle me-2"></i> No prescription history available for this patient.
                    </div>
                <?php endif; ?>

                <div class="mt-5 pt-4 border-top d-flex justify-content-between">
                    <a href="<?php echo e(route('doctor.dashboard')); ?>" class="btn btn-light px-4 rounded-pill">
                        <i class="bi bi-arrow-left me-2"></i> Back to Dashboard
                    </a>
                    <a href="<?php echo e(route('doctor.prescription.create', $patient->id)); ?>" class="btn btn-primary px-4 rounded-pill">
                        <i class="bi bi-plus-circle me-2"></i> New Prescription for <?php echo e($patient->name); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/doctor/prescriptions/history.blade.php ENDPATH**/ ?>