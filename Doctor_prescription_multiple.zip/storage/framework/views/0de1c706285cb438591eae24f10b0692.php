

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Dashboard</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Total Patients -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner">
                <h3><?php echo e($totalPatients); ?></h3>
                <p>Total Patients</p>
            </div>
            <div class="icon">
                <i class="fas fa-users"></i>
            </div>
            <a href="<?php echo e(route('admin.patients.index')); ?>" class="small-box-footer">
                View All <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <!-- Total Prescriptions -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3><?php echo e($totalPrescriptions); ?></h3>
                <p>Total Prescriptions</p>
            </div>
            <div class="icon">
                <i class="fas fa-file-prescription"></i>
            </div>
            <a href="<?php echo e(route('admin.prescriptions.index')); ?>" class="small-box-footer">
                View All <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <!-- Today's Prescriptions -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3><?php echo e($recentPrescriptions->where('created_at', '>=', now()->startOfDay())->count()); ?></h3>
                <p>Today's Prescriptions</p>
            </div>
            <div class="icon">
                <i class="fas fa-calendar-day"></i>
            </div>
            <a href="<?php echo e(route('admin.prescriptions.index')); ?>" class="small-box-footer">
                More info <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <!-- Total Doctors -->
    <div class="col-lg-3 col-6">
        <div class="small-box bg-purple" style="background-color: #6f42c1 !important; color: white;">
            <div class="inner">
                <h3><?php echo e($totalDoctors); ?></h3>
                <p>Total Doctors</p>
            </div>
            <div class="icon">
                <i class="fas fa-user-md" style="color: rgba(255,255,255,0.3)"></i>
            </div>
            <a href="<?php echo e(route('admin.doctors.index')); ?>" class="small-box-footer">
                View All <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
</div>

<!-- Recent Prescriptions -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header border-transparent">
                <h3 class="card-title">
                    <i class="fas fa-list mr-1"></i> Recent Prescriptions
                </h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>Prescription No</th>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Diagnosis</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentPrescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong><?php echo e($prescription->prescription_number); ?></strong></td>
                            <td><?php echo e($prescription->patient->name); ?></td>
                            <td><span class="badge badge-info"><?php echo e($prescription->doctor->name ?? 'System'); ?></span></td>
                            <td><?php echo e(Str::limit($prescription->diagnosis, 40)); ?></td>
                            <td><?php echo e($prescription->created_at->format('d M Y, h:i A')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.prescriptions.show', $prescription->id)); ?>" 
                                   class="btn btn-xs btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.prescriptions.print', $prescription->id)); ?>" 
                                   class="btn btn-xs btn-primary" 
                                   target="_blank">
                                    <i class="fas fa-print"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">No prescriptions found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Doctor_prescription\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>