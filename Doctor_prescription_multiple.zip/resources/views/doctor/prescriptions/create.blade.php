@extends('layouts.doctor')

@section('title', 'Create Prescription')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card border-0">
            <div class="card-header bg-white p-4 border-0">
                <h3 class="mb-0 fw-bold">
                    <i class="bi bi-file-earmark-medical text-primary me-2"></i> Create New Prescription
                </h3>
            </div>
            <div class="card-body p-4">
                @if ($errors->any())
                    <div class="alert alert-danger border-0 shadow-sm">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('doctor.prescription.store') }}" method="POST" id="prescriptionForm">
                    @csrf

                    <!-- Patient Information -->
                    <h5 class="mb-4 text-primary">
                        <i class="bi bi-person-badge me-2"></i> Patient Information
                    </h5>
                    <div class="row g-3 mb-5">
                        <div class="col-md-6">
                            <label for="name" class="form-label fw-semibold">Patient Name *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="name" 
                                   name="name" 
                                   value="{{ $patient->name ?? old('name') }}" 
                                   required>
                        </div>
                        <div class="col-md-3">
                            <label for="age" class="form-label fw-semibold">Age *</label>
                            <input type="number" 
                                   class="form-control" 
                                   id="age" 
                                   name="age" 
                                   value="{{ $patient->age ?? old('age') }}" 
                                   min="1" 
                                   required>
                        </div>
                        <div class="col-md-3">
                            <label for="gender" class="form-label fw-semibold">Gender *</label>
                            <select class="form-select" id="gender" name="gender" required>
                                <option value="">Select...</option>
                                <option value="Male" {{ (isset($patient) && $patient->gender == 'Male') || old('gender') == 'Male' ? 'selected' : '' }}>Male</option>
                                <option value="Female" {{ (isset($patient) && $patient->gender == 'Female') || old('gender') == 'Female' ? 'selected' : '' }}>Female</option>
                                <option value="Other" {{ (isset($patient) && $patient->gender == 'Other') || old('gender') == 'Other' ? 'selected' : '' }}>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="phone" class="form-label fw-semibold">Phone Number *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="phone" 
                                   name="phone" 
                                   value="{{ $patient->phone ?? old('phone') }}" 
                                   required>
                        </div>
                        <div class="col-md-6">
                            <label for="address" class="form-label fw-semibold">Address</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="address" 
                                   name="address" 
                                   value="{{ $patient->address ?? old('address') }}">
                        </div>
                    </div>

                    <!-- Prescription Details -->
                    <h5 class="mb-4 text-primary">
                        <i class="bi bi-clipboard2-pulse me-2"></i> Prescription Details
                    </h5>
                    <div class="row g-3 mb-5">
                        <div class="col-12">
                            <label for="diagnosis" class="form-label fw-semibold">Diagnosis *</label>
                            <textarea class="form-control" 
                                      id="diagnosis" 
                                      name="diagnosis" 
                                      rows="2" 
                                      required>{{ old('diagnosis') }}</textarea>
                        </div>
                        <div class="col-12">
                            <label for="notes" class="form-label fw-semibold">Additional Notes</label>
                            <div class="mb-3">
                                <small class="text-muted d-block mb-2">Quick select default notes:</small>
                                <div class="d-flex flex-wrap gap-2">
                                    @foreach($defaultNotes as $note)
                                        <button type="button" class="btn btn-sm btn-outline-secondary default-note-btn rounded-pill px-3" data-text="{{ $note->detail_text }}">
                                            <i class="bi bi-plus-circle me-1"></i> {{ Str::limit($note->detail_text, 30) }}
                                        </button>
                                    @endforeach
                                </div>
                            </div>
                            <textarea class="form-control" 
                                      id="notes" 
                                      name="notes" 
                                      rows="3"
                                      placeholder="Enter any additional instructions or observations...">{{ old('notes') }}</textarea>
                        </div>
                    </div>

                    <!-- Medicines -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="mb-0 text-primary"><i class="bi bi-capsule me-2"></i> Medicines</h5>
                    </div>

                    <div id="medicinesContainer">
                        <div class="medicine-row border rounded-4 p-4 mb-4 bg-light border-0 shadow-sm">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Medicine Name *</label>
                                    <select name="medicines[0][medicine_id]" class="form-select medicine-select" required>
                                        <option value="">Select Medicine</option>
                                        @foreach($medicines as $medicine)
                                            <option value="{{ $medicine->id }}" data-type="{{ $medicine->type }}" data-dosages="{{ $medicine->dosage_options }}">
                                                {{ $medicine->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label fw-semibold">Type *</label>
                                    <select name="medicines[0][type]" class="form-select medicine-type" required>
                                        <option value="tablet">Tablet</option>
                                        <option value="syrup">Syrup</option>
                                        <option value="capsule">Capsule</option>
                                        <option value="injection">Injection</option>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label fw-semibold">Dosage *</label>
                                    <div class="dosage-wrapper">
                                        <select name="medicines[0][dosage]" class="form-select medicine-dosage" required title="Select or enter custom dosage">
                                            <option value="">Select Dosage</option>
                                            <option value="custom_entry">Other (Type custom)...</option>
                                        </select>
                                        <input type="text" class="form-control custom-dosage-input mt-2" style="display: none;" placeholder="e.g. 1.5 tabs" title="Type custom dosage">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label fw-semibold">Duration *</label>
                                    <select name="medicines[0][duration]" class="form-select" required>
                                        <option value="3 days">3 days</option>
                                        <option value="5 days">5 days</option>
                                        <option value="7 days" selected>7 days</option>
                                        <option value="10 days">10 days</option>
                                        <option value="14 days">14 days</option>
                                        <option value="1 month">1 month</option>
                                    </select>
                                </div>
                                <div class="col-md-2 d-flex align-items-end">
                                    <div class="w-100">
                                        <label class="form-label fw-semibold">Timing *</label>
                                        <select name="medicines[0][instructions]" class="form-select" required>
                                            <option value="Before meal">Before meal</option>
                                            <option value="After meal" selected>After meal</option>
                                            <option value="During meal">During meal</option>
                                            <option value="Empty stomach">Empty stomach</option>
                                        </select>
                                    </div>
                                    <button type="button" class="btn btn-outline-danger ms-2 remove-medicine border-0" style="display: none; height: 38px;">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="text-center mb-5">
                        <button type="button" class="btn btn-outline-primary rounded-pill px-4 shadow-sm" id="add-medicine-bottom">
                            <i class="bi bi-plus-circle me-1"></i> Add Another Medicine
                        </button>
                    </div>

                    <!-- Submit Buttons -->
                    <div class="d-flex justify-content-between mt-5 pt-4 border-top">
                        <a href="{{ route('doctor.dashboard') }}" class="btn btn-light px-4 rounded-pill">
                            <i class="bi bi-arrow-left me-2"></i> Back to Dashboard
                        </a>
                        <button type="submit" class="btn btn-primary btn-lg px-5 rounded-pill shadow">
                            <i class="bi bi-save me-2"></i> Save & Preview
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="{{ asset('js/prescription.js') }}"></script>
@endsection
