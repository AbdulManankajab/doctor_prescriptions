@extends('layouts.doctor')

@section('title', 'Print Prescription')

@section('styles')
<style>
    @media print {
        @page {
            size: A4;
            margin: 15mm;
        }
        
        body {
            background: white !important;
        }
        
        .print-area {
            width: 100%;
            max-width: 100%;
            box-shadow: none !important;
        }
    }
    
    .prescription-header {
        border-bottom: 3px solid #667eea;
        margin-bottom: 20px;
        padding-bottom: 15px;
    }
    
    .clinic-name {
        font-size: 2rem;
        font-weight: bold;
        color: #667eea;
    }
    
    .prescription-table {
        border: 2px solid #dee2e6;
    }
    
    .prescription-table th {
        background-color: #f8f9fa;
        font-weight: 600;
    }
</style>
@endsection

@section('content')
<div class="row no-print mb-4">
    <div class="col-12 d-flex justify-content-between">
        <button onclick="window.print()" class="btn btn-primary px-4 rounded-pill">
            <i class="bi bi-printer me-2"></i> Print Prescription
        </button>
        <a href="{{ route('doctor.dashboard') }}" class="btn btn-outline-secondary px-4 rounded-pill">
            <i class="bi bi-house me-2"></i> Back to Dashboard
        </a>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card print-area border-0">
            <div class="card-body p-5">
                <!-- Clinic Header -->
                <div class="prescription-header text-center">
                    <div class="clinic-name mb-1">
                        <i class="bi bi-hospital"></i> Medical Clinic
                    </div>
                    <p class="mb-0 text-muted"><strong>Doctor:</strong> {{ $prescription->doctor->name }} 
                        @if($prescription->doctor->specialization)
                            | <strong>Specialty:</strong> {{ $prescription->doctor->specialization }}
                        @endif
                    </p>
                    <p class="mb-0 text-muted">Address: Medical Plaza, Central City | Phone: +1 234 567 8900</p>
                </div>

                <!-- Prescription Details -->
                <div class="row mb-4">
                    <div class="col-6">
                        <p class="mb-1"><strong>Prescription ID:</strong> {{ $prescription->prescription_number }}</p>
                        <p class="mb-1"><strong>Date & Time:</strong> {{ $prescription->created_at->format('d M Y, h:i A') }}</p>
                    </div>
                    <div class="col-6 text-end">
                        <p class="mb-1"><strong>Patient ID:</strong> {{ $prescription->patient->patient_number }}</p>
                    </div>
                </div>

                <!-- Patient Information -->
                <div class="border rounded-3 p-4 mb-4" style="background-color: #f8f9fa;">
                    <h6 class="mb-3 text-primary fw-bold">
                        <i class="bi bi-person-circle"></i> Patient Details
                    </h6>
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-2"><strong>Name:</strong> {{ $prescription->patient->name }}</p>
                            <p class="mb-2"><strong>Age/Gender:</strong> {{ $prescription->patient->age }} years | {{ $prescription->patient->gender }}</p>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <p class="mb-2"><strong>Phone:</strong> {{ $prescription->patient->phone }}</p>
                            @if($prescription->patient->address)
                                <p class="mb-0"><strong>Address:</strong> {{ $prescription->patient->address }}</p>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Diagnosis -->
                <div class="mb-4">
                    <h6 class="mb-2 text-primary fw-bold">
                        <i class="bi bi-clipboard2-pulse"></i> Diagnosis
                    </h6>
                    <div class="border rounded-3 p-3 bg-white">{{ $prescription->diagnosis }}</div>
                </div>

                <!-- Medicines -->
                <div class="mb-4">
                    <h6 class="mb-3 text-primary fw-bold">
                        <i class="bi bi-capsule"></i> RX Medications
                    </h6>
                    <table class="table table-bordered align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th width="30%">Medicine</th>
                                <th width="10%">Type</th>
                                <th width="15%">Dosage</th>
                                <th width="15%">Duration</th>
                                <th width="30%">Instructions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($prescription->items as $item)
                            <tr>
                                <td><strong>{{ $item->medicine->name }}</strong></td>
                                <td><span class="badge bg-light text-dark fw-normal">{{ ucfirst($item->type) }}</span></td>
                                <td>{{ $item->dosage }}</td>
                                <td>{{ $item->duration }}</td>
                                <td>{{ $item->instructions }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Additional Notes -->
                @if($prescription->notes)
                <div class="mb-4">
                    <h6 class="mb-2 text-primary fw-bold">
                        <i class="bi bi-sticky"></i> Additional Advice/Notes
                    </h6>
                    <div class="border rounded-3 p-3 bg-white" style="white-space: pre-line;">{{ $prescription->notes }}</div>
                </div>
                @endif

                <!-- Doctor Signature Section -->
                <div class="row mt-5 pt-4">
                    <div class="col-6">
                        <p class="small text-muted mb-0">Registered Doctor ID: {{ str_pad($prescription->doctor->id, 5, '0', STR_PAD_LEFT) }}</p>
                    </div>
                    <div class="col-6 text-end">
                        <div class="d-inline-block text-center mt-4">
                            <div style="border-top: 2px solid #333; width: 220px;">
                                <p class="mt-2 mb-0 fw-bold">Dr. {{ $prescription->doctor->name }}</p>
                                <small class="text-muted">Digital Signature Verified</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <div class="text-center mt-5 pt-4 border-top">
                    <small class="text-muted">
                        This document is a computer-generated prescription intended for medical use. 
                        Valid only if signed or authenticated by registered personnel.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
