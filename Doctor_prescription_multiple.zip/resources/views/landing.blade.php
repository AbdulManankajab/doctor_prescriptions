<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription System - Choice</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root {
            --primary: #4f46e5;
            --primary-dark: #4338ca;
            --admin-color: #6366f1;
            --doctor-color: #0ea5e9;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f3f4f6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            background-image: 
                radial-gradient(at 0% 0%, rgba(79, 70, 229, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(14, 165, 233, 0.05) 0px, transparent 50%);
        }

        .container {
            max-width: 900px;
            padding: 20px;
        }

        .header-section {
            text-align: center;
            margin-bottom: 50px;
        }

        .header-section h1 {
            font-weight: 800;
            color: #111827;
            letter-spacing: -0.025em;
            margin-bottom: 15px;
        }

        .header-section p {
            color: #6b7280;
            font-size: 1.1rem;
        }

        .portal-card {
            background: white;
            border: 1px solid rgba(0,0,0,0.05);
            border-radius: 24px;
            padding: 40px;
            text-align: center;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            text-decoration: none !important;
        }

        .portal-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.1);
            border-color: var(--primary);
        }

        .icon-box {
            width: 80px;
            height: 80px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 2.5rem;
            transition: all 0.3s ease;
        }

        .doctor-box {
            background-color: rgba(14, 165, 233, 0.1);
            color: var(--doctor-color);
        }

        .admin-box {
            background-color: rgba(99, 102, 241, 0.1);
            color: var(--admin-color);
        }

        .portal-card:hover .icon-box {
            transform: scale(1.1) rotate(5deg);
        }

        .portal-card h3 {
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 12px;
        }

        .portal-card p {
            color: #6b7280;
            font-size: 0.95rem;
            line-height: 1.6;
        }

        .btn-portal {
            margin-top: 25px;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-doctor {
            background-color: var(--doctor-color);
            color: white;
            border: none;
        }

        .btn-admin {
            background-color: var(--admin-color);
            color: white;
            border: none;
        }

        .portal-card:hover .btn-portal {
            padding-left: 35px;
            padding-right: 35px;
        }

        .badge-new {
            position: absolute;
            top: 20px;
            right: 20px;
            background: #ec4899;
            color: white;
            font-size: 0.7rem;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 20px;
            text-transform: uppercase;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header-section">
        <h1 class="display-4"><i class="bi bi-heart-pulse-fill text-danger"></i> Prescription System</h1>
        <p>Please select your portal to continue</p>
    </div>

    <div class="row g-4 justify-content-center">
        <!-- Doctor Portal -->
        <div class="col-md-5">
            <div class="portal-card">
                @auth('doctor')
                    <span class="badge-new bg-success">Logged In</span>
                @else
                    <span class="badge-new">Active</span>
                @endauth
                <div>
                    <div class="icon-box doctor-box">
                        <i class="bi bi-person-heart"></i>
                    </div>
                    <h3>Doctor Portal</h3>
                    <p>Manage your specific patients, create prescriptions, and view medical history.</p>
                </div>
                @auth('doctor')
                    <a href="{{ route('doctor.dashboard') }}" class="btn btn-portal btn-doctor">
                        Go to Dashboard <i class="bi bi-speedometer2 ms-2"></i>
                    </a>
                @else
                    <a href="{{ route('doctor.login') }}" class="btn btn-portal btn-doctor">
                        Access Portal <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                @endauth
            </div>
        </div>

        <!-- Admin Portal -->
        <div class="col-md-5">
            <div class="portal-card">
                @auth('admin')
                    <span class="badge-new bg-success">Logged In</span>
                @endauth
                <div>
                    <div class="icon-box admin-box">
                        <i class="bi bi-shield-lock"></i>
                    </div>
                    <h3>Admin Management</h3>
                    <p>Global oversight of doctors, medicines, system settings, and comprehensive reports.</p>
                </div>
                @auth('admin')
                    <a href="{{ route('admin.dashboard') }}" class="btn btn-portal btn-admin">
                        Go to Dashboard <i class="bi bi-speedometer2 ms-2"></i>
                    </a>
                @else
                    <a href="{{ route('admin.login') }}" class="btn btn-portal btn-admin">
                        Login as Admin <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                @endauth
            </div>
        </div>
    </div>

    <div class="text-center mt-5">
        <p class="text-muted small">© 2026 Medical Informatics Solutions. All rights reserved.</p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
